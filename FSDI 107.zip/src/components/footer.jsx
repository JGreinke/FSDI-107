import "./footer.css"; 

const FooterSection = () => {
    return(
        <div className="footer">
            <h6>Website created by Green-Key </h6>
        </div>
    )
}
export default FooterSection; 